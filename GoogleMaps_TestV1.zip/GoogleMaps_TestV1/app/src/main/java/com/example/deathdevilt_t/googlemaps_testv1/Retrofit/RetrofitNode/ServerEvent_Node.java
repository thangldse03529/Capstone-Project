package com.example.deathdevilt_t.googlemaps_testv1.Retrofit.RetrofitNode;

/**
 * Created by DeathDevil.T_T on 31-May-17.
 */

public class ServerEvent_Node {
    private ServerResponse_Node serverResponse;

    public ServerEvent_Node(ServerResponse_Node serverResponse) {
        this.serverResponse = serverResponse;
    }

    public ServerResponse_Node getServerResponse() {
        return serverResponse;
    }

    public void setServerResponse(ServerResponse_Node serverResponse) {
        this.serverResponse = serverResponse;
    }
}
